A Pen created at CodePen.io. You can find this one at http://codepen.io/cathydutton/pen/ldazc.

 A JavaScript Hangman game with canvas animatoin.